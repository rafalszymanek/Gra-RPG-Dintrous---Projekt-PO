#ifndef GAMECONTROLER_H
#define GAMECONTROLER_H

void gameControler();

#endif // GAMECONTROLER_H

