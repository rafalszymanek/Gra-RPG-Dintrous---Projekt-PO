#include "opponent.h"

opponentCharacter::opponentCharacter()
{

}

opponentCharacter::~opponentCharacter(){
    currentHealth=0;
    strenght = 0;
    mana = 0;
}
